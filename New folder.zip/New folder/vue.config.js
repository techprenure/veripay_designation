module.exports = {
  devServer:{
    proxy:'http://143.198.235.199'
  },
  transpileDependencies: [
    'vuetify'
  ]
}
