<template>
    <div>personal page
         <div> 
            <v-row>
                <v-col class="col-6"></v-col>
                 <v-col class="col-6"></v-col>
                  <v-col></v-col>
                   <v-col></v-col>
                    <v-col></v-col>
            </v-row>
              </div>
    </div>
     
    
 
</template>