<template>
  <v-app>
    <v-main>
      <router-view/>
    </v-main>
  </v-app>
</template>

<script>

export default {
  name: 'App',

  data: () => ({
    //
  }),
};
</script>

<style >
@import url("https://fonts.googleapis.com/css2?family=Mulish:wght@300&display=swap");
*{
  font-family: 'Mulish' ;
  
}
  ._flex-space-btw{
    display: flex;
    align-items: center;
    justify-content: space-between;
  }
  tbody tr:nth-of-type(even) {
  background-color: rgba(236, 237, 237);
}

.v-data-table-header {
  background-color: rgba(182, 183, 187, 0.842);
  font-weight: bolder;
  font-size: 17px !important;
}
</style>